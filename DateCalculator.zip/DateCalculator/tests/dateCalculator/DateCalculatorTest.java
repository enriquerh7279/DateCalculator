package dateCalculator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DateCalculatorTest {

    @Test
    void testAdd() {

        System.out.println("Test with 8/9/2010, add 5");
        Date d = new Date(8,9,2010);
        assertEquals("8/14/2010", DateCalculator.testAdd(5, d));

        System.out.println("Test with 12/15/2013, add 20");
        d = new Date(12,15,2013);
        assertEquals("1/19/2014", DateCalculator.testAdd(20, d));

        System.out.println("Test with 6/24/2014, add 10");
        d = new Date(6,24,2014);
        assertEquals("7/28/2014", DateCalculator.testAdd(10, d));

        System.out.println("Test with 2/14/2012, add 20");
        d = new Date(2,14,2012);
        assertEquals("3/19/2012", DateCalculator.testAdd(20, d));

        System.out.println("Test with 1/7/2020, add 60");
        d = new Date(1,7,2020);
        assertEquals("3/14/2020", DateCalculator.testAdd(60, d));

        //test if it will equate to feb 29th during a leap year
        System.out.println("Test with 02/28/2020, add 1");
        d = new Date(2,28,2020);
        assertEquals("2/29/2020", DateCalculator.testAdd(1, d));

        //test adding a number that falls within the same month
        System.out.println("Test with 6/24/2008, add 7");
        d = new Date(6,24,2008);
        assertEquals("7/1/2008", DateCalculator.testAdd(7, d));

        //my test
        System.out.println("Test with 2/29/2012, add 60");
        d = new Date(2,21,2012);
        assertEquals("2/29/2012", DateCalculator.testAdd(8, d));

        //my test
        System.out.println("Test with 1/7/2020, add 60");
        d = new Date(1,7,2020);
        assertEquals("3/14/2020", DateCalculator.testAdd(60, d));

        //my test
        System.out.println("Test with 1/7/2020, add 60");
        d = new Date(1,7,2020);
        assertEquals("3/14/2020", DateCalculator.testAdd(60, d));
    }

    void testValidation() {
        assertFalse(DateCalculator.testDateValidation(02,29,2011));
        assertFalse(DateCalculator.testDateValidation(02,12,2026));
        assertFalse(DateCalculator.testDateValidation(12,25,1999));
        assertFalse(DateCalculator.testDateValidation(02,29,1800));
        assertFalse(DateCalculator.testDateValidation(12,49,2002));
        assertFalse(DateCalculator.testDateValidation(22,07,2005));

        assertTrue(DateCalculator.testDateValidation(02,29,2020));
        assertTrue(DateCalculator.testDateValidation(06,06,2006));
        assertTrue(DateCalculator.testDateValidation(12,25,2008));
    }
}
package dateCalculator;

public class Date {

    private int day;
    private static Month month;
    private static int year;
    private static boolean isLeapYear;

    public Date(int mm, int dd, int yyyy) {
        if(mm == 13) {
            mm = 1;
            yyyy += 1;
        }
        year = yyyy;
        day = dd;
        isLeapYear = determineIfIsLeapYear(year);
        month = new Month(mm, isLeapYear);
    }

    private static boolean determineIfIsLeapYear(int year) {
        boolean isLeap =  false;
        //if the year is evenly divisible by 4, then it's a leap year
        if(year % 4 == 0) {
            isLeap = !isLeap;
            //if the year is also evenly divisible by 100, then it's NOT a leap year
            if(year % 100 == 0) {
                isLeap = !isLeap;
                //unless the year is also evenly divisible by 400, then it IS a leap year
                if(year % 400 == 0) isLeap = !isLeap; //true
            }
        }
        return isLeap;
    }

    public static boolean isLeapYear() {
        return isLeapYear;
    }

    public static boolean checkIfIsLeapYear(int yr) {
        return determineIfIsLeapYear(yr);
    }

    public int getDay() {
        return day;
    }

    public int getYear() {
        return year;
    }

    public Month getMonth() {
        return month;
    }

    public void incrementMonth() {
        if(month.getMonthNum() == 12) {
            this.month.increment(year);
            year++;
        } else month = new Month(month.getMonthNum() + 1, isLeapYear());
    }

    public static void setMonth(int num, boolean leap) {
        month = new Month(num, leap);
    }

    public void setDay(int day) {
        this.day = day;
    }
}

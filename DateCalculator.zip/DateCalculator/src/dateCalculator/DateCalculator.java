package dateCalculator;

import java.util.Scanner;

public class DateCalculator {

    private static int month;
    private static int day;
    private static int year;
    private static int daysToBeAdded;

    public static void main(String[] args) {
        promptForDate();
        promptForNumberOfDaysToAdd();
        System.out.println("\tAdd: " + daysToBeAdded + " days...");
        Date date = new Date(month, day, year);
        System.out.println(addDaysToCurrentDate(daysToBeAdded, date));
    }

    private static void promptForDate() {
        boolean isValid = false;
        do {
            Scanner s = new Scanner(System.in);
            String input = s.next();
            try {
                System.out.println("Enter a date int the format mm/dd/yyyy, the year must be between 2000 and 2025");
                month = Integer.parseInt(input.substring(0, 2));
                if(month > 12 || month < 1) continue;
                day = Integer.parseInt(input.substring(3, 5));
                if(day > 31 || day < 1) continue;
                year = Integer.parseInt(input.substring(6, 10));
                if(year > 2025 || year < 2000) continue;
                if(!validateDate(month, day, year)) continue;
                isValid = true;
            } catch(NumberFormatException e) {
                System.out.println("That input is not in the format mm/dd/yyyy, try again!");
            }
        }while (!isValid);
    }

    private static void promptForNumberOfDaysToAdd() {
        boolean isValid = false;
        do {
            System.out.println("Enter the number of days you want to add to the current date:");

            try {
                Scanner s = new Scanner(System.in);
                daysToBeAdded = s.nextInt();
                if(daysToBeAdded > 0 && daysToBeAdded < 61) isValid = true;
            } catch(NumberFormatException e) {
                System.out.println("That input is not a number from 1 to 60, try again!");
            }
        }while (!isValid);
    }

    private static String addDaysToCurrentDate(int daysToAdd, Date date) {

        /*if sum of the number of days and the current date are
            greater than the number of days in the current month, subtract the number of
            days left in the current month from the days to be added.
         */
        int sumOfDays = daysToAdd + date.getDay();
        if(sumOfDays > date.getMonth().getNumOfDaysInMonth()) {
            while(sumOfDays > date.getMonth().getNumOfDaysInMonth()) {//true 43 > 29
                if(date.getDay()>date.getMonth().getNumOfDaysInMonth()) date.setDay(0);
                int daysLeftInMonth = date.getMonth().getNumOfDaysInMonth() - date.getDay(); //29 - 43 =
                sumOfDays -= daysLeftInMonth;
                date.incrementMonth();
                date.setDay(sumOfDays);
            }
//            sumOfDays -= daysLeftInMonth;
//            date.incrementMonth();
//            date.setDay(sumOfDays);
            System.out.println("\tReturned: " + date.getMonth().getMonthNum() + "/" + date.getDay() + "/" + date.getYear());
            return date.getMonth().getMonthNum() + "/" + date.getDay() + "/" + date.getYear();
        } else {
            date.setDay(sumOfDays);
            System.out.println("\tReturned: " + date.getMonth().getMonthNum() + "/" + date.getDay() + "/" + date.getYear());
            return date.getMonth().getMonthNum() + "/" + date.getDay() + "/" + date.getYear();
        }
    }
    public static String testAdd(int daysTBA, Date d) {
        return addDaysToCurrentDate(daysTBA, d);
    }

    private static boolean validateDate(int month, int day, int year) {
        if(year > 2025 || year < 2000) return false;
        int daysInMonth = Month.getDaysInMonth(month, year);
        if(day <= daysInMonth) return true;
        return false;
    }

    public static boolean testDateValidation(int mm, int dd, int yyyy) {
        return validateDate(mm,dd,yyyy);
    }
}

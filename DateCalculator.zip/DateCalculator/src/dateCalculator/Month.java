package dateCalculator;

public class Month {

    private int numOfDaysInMonth;
    private int monthNum;
    private String name;
    private boolean isInLeapYear;

    public Month(int n, boolean isLeap) {

        isInLeapYear = isLeap;
        monthNum = n;

        switch (n) {
            case 1:
                name = "January";
                numOfDaysInMonth = 31;
                break;

            case 2:
                name = "February";
                if(isInLeapYear) {
                    numOfDaysInMonth = 29;
                } else numOfDaysInMonth = 28;
                break;


            case 3:
                name = "March";
                numOfDaysInMonth = 31;
                break;

            case 4:
                name = "April";
                numOfDaysInMonth = 30;
                break;

            case 5:
                name = "May";
                numOfDaysInMonth = 31;
                break;

            case 6:
                name = "June";
                numOfDaysInMonth = 30;
                break;

            case 7:
                name = "July";
                numOfDaysInMonth = 31;
                break;

            case 8:
                name = "August";
                numOfDaysInMonth = 31;
                break;

            case 9:
                name = "September";
                numOfDaysInMonth = 30;
                break;

            case 10:
                name = "October";
                numOfDaysInMonth = 31;
                break;

            case 11:
                name = "November";
                numOfDaysInMonth = 30;
                break;

            case 12:
                name = "December";
                numOfDaysInMonth = 31;
                break;
        }
    }

    public int getNumOfDaysInMonth() {
        return numOfDaysInMonth;
    }

    public int getMonthNum() {
        return monthNum;
    }

    public void increment(int year) {
        monthNum++;
        if(monthNum > 12) {
            monthNum = 1;
        }
        isInLeapYear = Date.checkIfIsLeapYear(year);
        Date.setMonth(monthNum, isInLeapYear);
    }

    public static int getDaysInMonth(int monthNumber, int year) {

        boolean isLeap = false;
        //if the year is evenly divisible by 4, then it's a leap year
        if (year % 4 == 0) {
            isLeap = !isLeap;
            //if the year is also evenly divisible by 100, then it's NOT a leap year
            if (year % 100 == 0) {
                isLeap = !isLeap;
                //unless the year is also evenly divisible by 400, then it IS a leap year
                if (year % 400 == 0) isLeap = !isLeap; //true
            }
        }

        switch (monthNumber) {
            case 1:
                return 31;

            case 2:
                if (isLeap) return 29;
                return 28;

            case 3:
                return 31;

            case 4:
                return 30;

            case 5:
                return 31;

            case 6:
                return 30;

            case 7:
                return 31;

            case 8:
                return 31;

            case 9:
                return 30;

            case 10:
                return 31;

            case 11:
                return 30;

            case 12:
                return 31;
        }
        return 0; //this should never return
    }
}

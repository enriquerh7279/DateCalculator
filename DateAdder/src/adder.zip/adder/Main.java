package adder;

public class Main {

    public static void main(String[] args) {
        DateCalculator dc = new DateCalculator();
    }
}

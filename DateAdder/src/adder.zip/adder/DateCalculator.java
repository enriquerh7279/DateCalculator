package adder;

import java.util.InputMismatchException;
import java.util.Scanner;

public class DateCalculator {

    private Date enteredDate;
    private int daysToAdd;

    public DateCalculator() { //missing static
        getDate();
        getDaysToAdd();
        Date [] dateArr = fillArr();
//        for(Date d : dateArr) {
//            d.print();
//        }
    }

    private void getDate() {

        String input;
        int day = 0;
        int month = 0;
        int year = 0;
        boolean isValid = false;
        Date d = new Date();

        try {
            do {
                System.out.println("Enter a date in the following format: mm/dd/yyyy");
                Scanner s = new Scanner((System.in));
                input = s.next();
                month = Integer.parseInt(input.substring(0, 2));
                if (!d.isValidMonth(month)) continue;
                year = Integer.parseInt(input.substring(6, 10));
                if (!d.isValidYear(year)) continue;
                day = Integer.parseInt(input.substring(3, 5));
                if (!d.isValidDay(month, day, year)) continue;
                enteredDate = new Date(month, day, year);
                isValid = !isValid;
            } while (isValid == false);
        } catch (NumberFormatException e) {
            System.out.println("Error formatting string into int");
        } catch(InputMismatchException e) {
            System.out.println("That is not a valid input!");
        }
    }

    private void getDaysToAdd() {
        boolean inputIsValid = false;
        try{
            do{
                System.out.println("Enter a number 1 to 60 to add to the previously entered date");
                Scanner s = new Scanner(System.in);
                daysToAdd = s.nextInt();
                if(daysToAdd > 60 || daysToAdd < 1) continue;
                inputIsValid = !inputIsValid;
            }while (!inputIsValid);
        } catch (NumberFormatException e) {
            System.out.println("An error occured whe trying to parse number of days to add.");
        } catch(InputMismatchException e) {
            System.out.println("That is not a valid input!");
        }
    }

    private Date[] fillArr() {
        int enteredMonth = enteredDate.getMonth();
        int enteredDay = enteredDate.getDay();
        int enteredYear = enteredDate.getYear();
        boolean isValid;
        Date[] arr = new Date[daysToAdd];

        for(int i = 0; i < daysToAdd; i++) {
            isValid = false;
            while (!isValid) {
                enteredDay++;
                Date date = new Date(enteredMonth, enteredDay, enteredYear);
                System.out.println(date.toString() + " is " + date.isValidDate());
                if (date.isValidDate()) {//if the date of the next number is valid, add it to the array
                    isValid = true;
                    arr[i] = new Date(enteredMonth, enteredDay, enteredYear);
                } else { //it's not, so we will try again with the first of the next month
                    if (date.getDay() > date.getMaxDaysInMonth()) {
                        enteredDay = 0;
                        enteredMonth++;
                        if (enteredMonth == 13) { //if the next month will be in the next year
                            enteredMonth = 1;
                            enteredYear++;
                        }
                    }
                }
            }
        }
        return arr;
    }
//    private static Date addDaysToDate() {
//        int enteredDay = enteredDate.getDay();
//        int monthMax = Date.getMaxDaysInMonth(enteredDate.getMonth(), enteredDate.getYear());
//        int sumOfDays = enteredDay + daysToAdd;
//
//        //if the sum of the days is before or at the end of the month the date is in this month
//        boolean dateIsInThisMonth = (sumOfDays <= monthMax);
//
//        int newMonth = enteredDate.getMonth();
//        int newDay;
//        if(dateIsInThisMonth) {
//            newDay = sumOfDays;
//        } else {
//            newDay = enteredDay;
//        }
//        int newYear = enteredDate.getYear();
//        int daysLeftInMonth;
//
//        //while the date isn't in this month
//        //we need to increment the month until the day falls into the
//        //current month
//        while(!dateIsInThisMonth) {
//            daysLeftInMonth = Date.getMaxDaysInMonth(newMonth, newYear) - enteredDay;
//            sumOfDays -= daysLeftInMonth;
//            newMonth ++;
//            if(!Date.isValidMonth(newMonth)) {
//                newMonth = 1;
//                newYear++;
//            }
//            enteredDay = 1;
//            sumOfDays--;
//            dateIsInThisMonth = (sumOfDays <= Date.getMaxDaysInMonth(newMonth,newYear));
//        }
//            return new Date(newMonth, enteredDay, newYear);
//    }
}
